"""
URL configuration for lms_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from core import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='home'),
    
    # Auth Endpoints
    path('auth/register', views.RegisterView.as_view(), name='register'),
    path('auth/login', views.LoginView.as_view(), name='login'),
    path('auth/me', views.MeView.as_view(), name='me'),
    
    # Courses & Modules (V1)
    path('courses/', views.CourseListCreateView.as_view(), name='course_list'),
    path('courses/<int:pk>', views.CourseDetailView.as_view(), name='course_detail'),
    path('courses/<int:course_id>/modules', views.AddModuleView.as_view(), name='add_module'),
    
    # Enrollments (V1)
    path('courses/<int:course_id>/enroll', views.EnrollCourseView.as_view(), name='enroll'),
    path('courses/<int:course_id>/unenroll', views.UnenrollCourseView.as_view(), name='unenroll'),
    path('my-enrollments', views.MyEnrollmentsView.as_view(), name='my_enrollments'),
    path('modules/<int:module_id>/quiz/', views.QuizDetailView.as_view(), name='module_quiz'),
    path('quizzes/<int:quiz_id>/submit/', views.SubmitQuizView.as_view(), name='submit_quiz'),
]